import os
import sys

def install():
    # 1. Get the current folder where the user unzipped the game
    current_folder = os.getcwd()
   
    # 2. Detect the game file (looks for the binary)
    bin_name = "truth_engine0925"
    icon_name = "icon_linux.png"
   
    if not os.path.exists(bin_name):
        print(f"❌ Error: I can't find {bin_name}!")
        print("   Make sure you run this script inside the game folder.")
        input("Press Enter to exit...")
        return

    # 3. Create the path for the shortcut
    home_dir = os.path.expanduser("~")
    shortcut_path = os.path.join(home_dir, ".local/share/applications/truth_engine.desktop")
   
    bin_full_path = os.path.join(current_folder, bin_name)
    icon_full_path = os.path.join(current_folder, icon_name)

    # 4. Write the shortcut
    content = f"""[Desktop Entry]
Version=1.0
Type=Application
Name=Truth Engine
Comment=Truth Engine Simulator
Exec="{bin_full_path}"
Path={current_folder}
Icon={icon_full_path}
Terminal=true
StartupNotify=true
Categories=Game;
"""
   
    try:
        with open(shortcut_path, "w") as f:
            f.write(content)
        print("✅ SUCCESS! Truth Engine has been installed to your App Menu.")
        print("   Press your Super/Windows key and search for 'Truth'.")
    except Exception as e:
        print(f"❌ Error creating shortcut: {e}")

    input("Press Enter to exit...")

if __name__ == "__main__":
    install()
