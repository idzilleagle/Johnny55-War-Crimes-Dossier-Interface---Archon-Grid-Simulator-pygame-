#!/bin/bash
python3 install_game.py